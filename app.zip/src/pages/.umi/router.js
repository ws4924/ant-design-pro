import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import RendererWrapper0 from 'D:/Ant-design-Pro/app/src/pages/.umi/LocaleWrapper.jsx';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/user',
    component: require('../../layouts/UserLayout').default,
    routes: [
      {
        name: 'login',
        path: '/user/login',
        component: require('../user/login').default,
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('D:/Ant-design-Pro/app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    path: '/',
    component: require('../../layouts/SecurityLayout').default,
    routes: [
      {
        path: '/',
        component: require('../../layouts/BasicLayout').default,
        authority: ['admin', 'user'],
        routes: [
          {
            path: '/',
            redirect: '/DashboardWorkplace',
            exact: true,
          },
          {
            name: 'DashboardWorkplace',
            icon: 'smile',
            path: '/DashboardWorkplace',
            component: require('../DashboardWorkplace').default,
            exact: true,
          },
          {
            path: '/welcome',
            name: 'welcome',
            icon: 'smile',
            component: require('../Welcome').default,
            exact: true,
          },
          {
            path: '/admin',
            name: 'admin',
            icon: 'crown',
            component: require('../Admin').default,
            authority: ['admin'],
            exact: true,
          },
          {
            path: '/account',
            name: 'account',
            icon: 'user',
            routes: [
              {
                path: '/account/center',
                name: 'center',
                icon: 'idcard',
                component: require('../account/center').default,
                authority: ['admin', 'user'],
                exact: true,
              },
              {
                path: '/account/table',
                name: 'table',
                icon: 'user',
                component: require('../account/table').default,
                authority: ['admin', 'user'],
                exact: true,
              },
              {
                path: '/account/table-tab',
                name: 'table-tab',
                icon: 'user',
                component: require('../account/table-tab').default,
                authority: ['admin', 'user'],
                exact: true,
              },
              {
                path: '/account/modal',
                name: 'modal',
                icon: 'user',
                component: require('../account/modal').default,
                authority: ['admin', 'user'],
                exact: true,
              },
              {
                path: '/account/account-message',
                name: 'account-message',
                icon: 'money-collect',
                component: require('../account/account-message').default,
                authority: ['admin', 'user'],
                exact: true,
              },
              {
                path: '/account/change-phone-number',
                name: 'change-phone-number',
                icon: 'mobile',
                component: require('../account/change-phone-number').default,
                authority: ['admin', 'user'],
                exact: true,
              },
              {
                path: '/account/change-password',
                name: 'change-password',
                icon: 'key',
                component: require('../account/change-password').default,
                authority: ['admin', 'user'],
                exact: true,
              },
              {
                path: '/account/detail',
                component: require('../account/detail').default,
                hidden: true,
                routes: [
                  {
                    name: '详情',
                    path: '/account/detail',
                    component: require('../account/detail').default,
                    exact: true,
                  },
                  {
                    component: () =>
                      React.createElement(
                        require('D:/Ant-design-Pro/app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                          .default,
                        { pagesPath: 'src/pages', hasRoutesInConfig: true },
                      ),
                  },
                ],
              },
              {
                component: require('../404').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/Ant-design-Pro/app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/partsOffer/partsOffer',
            name: 'partsOffer',
            icon: 'crown',
            component: require('../partsOffer/partsOffer').default,
            authority: ['admin'],
            exact: true,
          },
          {
            path: '/example/example',
            name: 'example',
            icon: 'crown',
            component: require('../example/example').default,
            authority: ['admin'],
            exact: true,
          },
          {
            component: require('../404').default,
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('D:/Ant-design-Pro/app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        component: require('../404').default,
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('D:/Ant-design-Pro/app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: require('../404').default,
    exact: true,
  },
  {
    component: () =>
      React.createElement(
        require('D:/Ant-design-Pro/app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
